package exercicio2;

import java.util.logging.Level;
import java.util.logging.Logger;
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author monte
 */
public class ThreadCrescente extends Thread {
    @Override
    public void run (){
        for (int i = 0; i<=100; i++){
            System.out.println("Thread Crescente " +i);
        }
        try {
                Thread.sleep(100);
            } catch (InterruptedException ex) {
                Logger.getLogger(ThreadCrescente.class.getName()).log(Level.SEVERE, null, ex);
            }
    }
}
