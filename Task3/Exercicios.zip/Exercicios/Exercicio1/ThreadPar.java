/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package exercicio1;

import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author monte
 */
public class ThreadPar extends Thread {
    
    @Override
    public void run (){
        for (int i = 0; i<=100; i+=2){
            System.out.println("Thread Par " +i);
        }
        
//        for (int i = 0; i<=100; i++){
//            if ((i % 2) == 0)
//               System.out.println("Thread Par " +i);
//        }
        
        try {
                Thread.sleep(100);
            } catch (InterruptedException ex) {
                Logger.getLogger(ThreadPar.class.getName()).log(Level.SEVERE, null, ex);
            }
    }
    
}
